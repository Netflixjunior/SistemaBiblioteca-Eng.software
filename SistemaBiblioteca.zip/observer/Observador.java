package observer;

public interface Observador {

    void notificar();

}
