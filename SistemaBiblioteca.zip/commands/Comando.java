package commands;

public interface Comando {

    void executar(String[] args);
}
